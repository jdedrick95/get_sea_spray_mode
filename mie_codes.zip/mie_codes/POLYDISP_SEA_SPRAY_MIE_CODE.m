% POLYDISP_SEA_SPRAY_MIE_CODE
%
% Simulates Mie scattering coefficients for sea spray size distributions.
%
% Inputs:
%
% !!! Function Mie_abcd.m and Mie_abcd_coating.m are required to run !!!
%
%
% Outputs:
%
% b_sca: scattering coefficients at 450, 550, and 700 nm [450, 550, 700].
%
% coeff: size distribution fitting parameters [number, geometric mean
% diameter, geometric standard deviation].
%
%
%
% Written by: Geroges Saliba
%             Scripps Institution of Oceanography
%             21 November 2019
%             Last edited 16 January 2022
% 


clc;

% wavelength (nm)
lemda = [450 550 700];

% density (kg/m3):
ro_BC = 2200;
ro_OA = 1200;

% refractive index of core BC (Bond et al. 2005):
m_core = 1.56; %ri_nacl = 1.56 and weakly wavelength dependent

% refractive index of OA:
R_OA  = 1.56;
k_550 = 0;
wd    = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Constructing the coarse mode size distribution %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N     = [1:1:100];         % number concentration
Sigma = [1.0:0.1:3.0];     % geometric standard deviation
mu    = [0.05:0.02:1.2];   % geometric mean diameter

oabc=0;
D = logspace(log10(0.0104), log10(11), 100);
ii=1;
clear dNdlog dNdlog_temp b_sca dN coeff coeff_temp
for i=1:length(N)
    for j = 1:length(mu)
        for k = 1:length(Sigma)
            dNdlog_temp{ii}(k,:) = N(i)/(sqrt(2*pi)*log10(Sigma(k)))*exp(-((log10(D)-log10(mu(j))).^2)/(2*log10(Sigma(k))^2));  
            coeff_temp{ii}(k,:) = [N(i) mu(j) Sigma(k)];
        end
        ii=ii+1;
    end
end

coeff = coeff_temp{1};
dNdlog = dNdlog_temp{1};
for i=2:length(dNdlog_temp)
    dNdlog = [dNdlog;dNdlog_temp{i}];
    coeff = [coeff;coeff_temp{i}];
end

dN = dNdlog*0.0305;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% Mie Code %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

d_core = 1000*D;

for k=1:length(lemda)
    for j=1:length(dN)
        for i=1:length(d_core)
            
            d_shell(i)=d_core(i)*((ro_BC/ro_OA).*oabc+1).^(1/3); %use oa(i) if monodisperse
            
            mp_core(i) = pi .* (d_core(i) .* 1e-9).^3 / 6 .* ro_BC * 1e3;
            mp_tot(i) = mp_core(i) + pi .* ((d_shell(i) .* 1e-9).^3 - (d_core(i) .* 1e-9).^3) / 6 .* ro_OA * 1e3;
            
            m_shell = R_OA + k_550*550^wd/lemda(k)^wd;
            %     m_shell_up = 1.55 + k_550_up*550^wd_up/lemda^wd_up * i;
            %     m_shell_low = 1.55 + k_550_low*550^wd_low/lemda^wd_low * i;
            %     m_core = m_shell;
            
            % size factor:
            x_core = pi .* d_core(i)./lemda(k);
            x_shell = pi .* d_shell(i)./lemda(k);
            
            % get results from homo and coating functions:
            Array_BC = Mie_abcd(m_core, x_core);
            Array_OA = Mie_abcd(m_shell, x_shell);
            Array_c = Mie_abcd_coating(m_core , m_shell, x_core, x_shell);
            Array_OA_c = Mie_abcd_coating(m_shell , m_shell, x_shell, x_shell);
            
            an = Array_BC(1,:);
            bn = Array_BC(2,:);
            an_OA = Array_OA(1,:);
            bn_OA = Array_OA(2,:);
            
            an_1 = Array_c(3,:);
            bn_1 = Array_c(4,:);
            an_c = Array_c(1,:);
            bn_c = Array_c(2,:);
            an_OA_c = Array_OA_c(3,:);
            bn_OA_c = Array_OA_c(4,:);
            
            
            % get the real and imaginary parts:
            Re_an = real(an);
            Im_an = imag(an);
            Re_bn = real(bn);
            Im_bn = imag(bn);
            Re_an_OA = real(an_OA);
            Im_an_OA = imag(an_OA);
            Re_bn_OA = real(bn_OA);
            Im_bn_OA = imag(bn_OA);
            
            
            Re_an_1 = real(an_1);
            Im_an_1 = imag(an_1);
            Re_bn_1 = real(bn_1);
            Im_bn_1 = imag(bn_1);
            Re_an_c = real(an_c);
            Im_an_c = imag(an_c);
            Re_bn_c = real(bn_c);
            Im_bn_c = imag(bn_c);
            Re_an_OA_c = real(an_OA_c);
            Im_an_OA_c = imag(an_OA_c);
            Re_bn_OA_c = real(bn_OA_c);
            Im_bn_OA_c = imag(bn_OA_c);
            
            
            n = [1:length(an)];
            n_OA = [1:length(an_OA)];
            % the efficiencies: _c is for coating
            % scattering efficiency:
            Q_sca_BC = 2 ./ x_core.^2 .* sum((2*n+1) .* (Re_an.^2 + Im_an.^2 + Re_bn.^2 + Im_bn.^2));
            Q_sca_OA = 2 ./ x_shell.^2 .* sum((2*n_OA+1) .* (Re_an_OA.^2 + Im_an_OA.^2 + Re_bn_OA.^2 + Im_bn_OA.^2));
            
            Q_sca_BC_1 = 2 ./ x_core.^2 .* sum((2*n+1) .* (Re_an_1.^2 + Im_an_1.^2 + Re_bn_1.^2 + Im_bn_1.^2));
            Q_sca_c = 2 ./ x_shell.^2 .* sum((2*n+1) .* (Re_an_c.^2 + Im_an_c.^2 + Re_bn_c.^2 + Im_bn_c.^2));
            Q_sca_OA_c = 2 ./ x_shell.^2 .* sum((2*n_OA+1) .* (Re_an_OA_c.^2 + Im_an_OA_c.^2 + Re_bn_OA_c.^2 + Im_bn_OA_c.^2));
            
            % extinction efficiency:
            Q_ext_BC =  2 ./ x_core.^2 .* sum((2*n+1) .* (Re_an + Re_bn));
            Q_ext_OA =  2 ./ x_shell.^2 .* sum((2*n_OA+1) .* (Re_an_OA + Re_bn_OA));
            
            Q_ext_BC_1 =  2 ./ x_core.^2 .* sum((2*n+1) .* (Re_an_1 + Re_bn_1));
            Q_ext_c =  2 ./ x_shell.^2 .* sum((2*n+1) .* (Re_an_c + Re_bn_c));
            Q_ext_OA_c =  2 ./ x_shell.^2 .* sum((2*n_OA+1) .* (Re_an_OA_c + Re_bn_OA_c));
            
            % absorption efficiency:
            %         Q_abs_BC = Q_ext_BC - Q_sca_BC;
            %         Q_abs_OA = Q_ext_OA - Q_sca_OA;
            %
            %         Q_abs_BC_1 = Q_ext_BC_1 - Q_sca_BC_1;
            %         Q_abs_c = Q_ext_c - Q_sca_c;
            %         Q_abs_OA_c = Q_ext_OA_c - Q_sca_OA_c;
            
            
            % my calculations:
            % particle crossection (m2):
            A_cross_core = pi .* (d_core(i) * 1e-9)^2 / 4;
            A_cross_shell = pi .* (d_shell(i) * 1e-9)^2 / 4;
            
            % absorption coress sections (m2):
            %         Sigma_BC(i) =  Q_abs_BC .* A_cross_core;
            %         Sigma_OA =  Q_abs_OA .* A_cross_shell;
            %
            %         Sigma_BC_1 =  Q_abs_BC_1 .* A_cross_core;
            %         Sigma_c(i) =  Q_abs_c .* A_cross_shell;
            %         Sigma_OA_c =  Q_abs_OA_c .* A_cross_shell;
            
            % scattering coressections:
            Sigma_sca_BC(i) =  Q_sca_BC .* A_cross_core;
            Sigma_sca_OA(i) =  Q_sca_OA .* A_cross_shell;
            
            Sigma_sca_BC_1 =  Q_sca_BC_1 .* A_cross_core;
            Sigma_sca_c(i) =  Q_sca_c .* A_cross_shell; %internally mixed OA
            Sigma_sca_OA_c(i) =  Q_sca_OA_c .* A_cross_shell; %externally mixed OA
        end
        
        %absorption
        %     Sigma_BC_tot(j)=sum(dN_BC(j,:).*Sigma_BC);
        %     Sigma_c_tot(j)=sum(dN_BC(j,:).*Sigma_c);
        %     b_abs = Sigma_BC_tot*10^12;
        
        %scattering
        Sigma_sca_c_tot=sum(dN(j,:).*Sigma_sca_OA);
        b_sca(j,k) = Sigma_sca_c_tot*10^12; %units: 1/Mm
        
        %SSA
        %     ssa(j)=Sigma_sca_c_tot(j)/(Sigma_sca_c_tot(j)+Sigma_BC_tot(j));
        
        mp_core_tot(j)=sum(dN(j,:).*mp_core);
        mp_tot_tot(j)=sum(dN(j,:).*mp_tot);
        

    end
     
 
    
end


time_now = now;
time_now = datestr(time_now, 'yymmdd_HHMM');
save(strcat('mie_code_out_', time_now,'.mat'), 'b_sca', 'coeff')


