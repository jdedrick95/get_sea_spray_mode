% Mie_abcd_coating(m1, m2, x, y)
%
% Computes a matrix of Mie coefficients, a_n, b_n, c_n, d_n,
% of orders n=1 to nmax, complex refractive index m=m'+im",
% and size parameter x=k0*a, where k0= wave number
% in the ambient medium, a=sphere radius;
% p. 100, 477 in Bohren and Huffman (1983) BEWI:TDD122
% C. M�tzler, June 2002
%
% Inputs:
%
% m1, m2: core and shell refractive indices. 
%
% xm y: core and shell size factors
%
%
% Outputs: 
%
%
% result: Mie coefficient matrix.
%
%
%
% Written by: Geroges Saliba
%             Scripps Institution of Oceanography
%             21 November 2019
%             Last edited 16 January 2022
% 


function result = Mie_abcd_coating(m1, m2, x, y)
% Computes a matrix of Mie coefficients, a_n, b_n, c_n, d_n,
% of orders n=1 to nmax, complex refractive index m=m'+im",
% and size parameter x=k0*a, where k0= wave number
% in the ambient medium, a=sphere radius;
% p. 100, 477 in Bohren and Huffman (1983) BEWI:TDD122
% C. M�tzler, June 2002

% this function is edited by me to account for coating with size parameter
% y and refreactive index m2. I use equation 8.2 from Bohren and Huffman,
% but I change the vairbales to be consistent with Matzler 2002.
% i am also adding comments because Matzler's code lacks a bit of
% commenting:

% maximum order based on BH:
nmax=round(2+x+4*x^(1/3)) *2;
n=(1:nmax);
% this is to calculate the spherical bessel functions:
nu = (n+0.5); 

% reduce some variables:
z1 = m1.*x; 
z2 = m2 .* x;
z3 = m2 .* y;
% these are useful to cauclate spherical functions
sqx = sqrt(0.5*pi./x); 
sqy = sqrt(0.5*pi./y); 
sqz1 = sqrt(0.5*pi./z1);
sqz2 = sqrt(0.5*pi./z2);
sqz3 = sqrt(0.5*pi./z3);

% spherical bessel functions
Jn_x = besselj(nu, x).*sqx;
Jn_y = besselj(nu, y).*sqy;
Jn_z1 = besselj(nu, z1).*sqz1;
Jn_z2 = besselj(nu, z2).*sqz2;
Jn_z3 = besselj(nu, z3).*sqz3;

Yn_x = bessely(nu, x).*sqx;
Yn_y = bessely(nu, y).*sqy;
Yn_z1 = bessely(nu, z1).*sqz1;
Yn_z2 = bessely(nu, z2).*sqz2;
Yn_z3 = bessely(nu, z3).*sqz3;

% spherical Hanckel functions:
Hn_x = Jn_x + i * Yn_x;
Hn_y = Jn_y + i * Yn_y;
Hn_z1 = Jn_z1 + i * Yn_z1;
Hn_z2 = Jn_z2 + i * Yn_z2;
Hn_z3 = Jn_z3 + i * Yn_z3;

% the derivatives (p.127 in BH):
% I need to calculate the spherical functions from n=0 to nmax-1:
Jn_x_offset = [sin(x)/x, Jn_x(1:nmax-1)];
Jn_y_offset = [sin(y)/y, Jn_y(1:nmax-1)];
Jn_z1_offset = [sin(z1)/z1, Jn_z1(1:nmax-1)];
Jn_z2_offset = [sin(z2)/z2, Jn_z2(1:nmax-1)];
Jn_z3_offset = [sin(z3)/z3, Jn_z3(1:nmax-1)];

Yn_x_offset = [-cos(x)/x, Yn_x(1:nmax-1)];
Yn_y_offset = [-cos(y)/y, Yn_y(1:nmax-1)];
Yn_z1_offset = [-cos(z1)/z1, Yn_z1(1:nmax-1)];
Yn_z2_offset = [-cos(z2)/z2, Yn_z2(1:nmax-1)];
Yn_z3_offset = [-cos(z3)/z3, Yn_z3(1:nmax-1)];

Hn_x_offset = Jn_x_offset + i * Yn_x_offset;
Hn_y_offset = Jn_y_offset + i * Yn_y_offset;
Hn_z1_offset = Jn_z1_offset + i * Yn_z1_offset;
Hn_z2_offset = Jn_z2_offset + i * Yn_z2_offset;
Hn_z3_offset = Jn_z3_offset + i * Yn_z3_offset;

% now the derivatives!:
Jn_x_prime = x .* Jn_x_offset - n .* Jn_x;
Jn_y_prime = y .* Jn_y_offset - n .* Jn_y;
Jn_z1_prime = z1 .* Jn_z1_offset - n .* Jn_z1;
Jn_z2_prime = z2 .* Jn_z2_offset - n .* Jn_z2;
Jn_z3_prime = z3 .* Jn_z3_offset - n .* Jn_z3;

Yn_x_prime = x .* Yn_x_offset - n .* Yn_x;
Yn_y_prime = y .* Yn_y_offset - n .* Yn_y;
Yn_z1_prime = z1 .* Yn_z1_offset - n .* Yn_z1;
Yn_z2_prime = z2 .* Yn_z2_offset - n .* Yn_z2;
Yn_z3_prime = z3 .* Yn_z3_offset - n .* Yn_z3;

Hn_x_prime = x .* Hn_x_offset - n .* Hn_x;
Hn_y_prime = y .* Hn_y_offset - n .* Hn_y;
Hn_z1_prime = z1 .* Hn_z1_offset - n .* Hn_z1;
Hn_z2_prime = z2 .* Hn_z2_offset - n .* Hn_z2;
Hn_z3_prime = z3 .* Hn_z3_offset - n .* Hn_z3;


% now calculate an_c and bn_c, but first we need An and Bn:

An = (m2.^2 .* x .* Jn_z2 .* Jn_z1_prime - m1 .* Jn_z2_prime .* m1 .* x .* Jn_z1) ...
    ./ (m1 .* Yn_z2_prime .* m1 .* x .* Jn_z1 - m2.^2 .* x .* Yn_z2 .* Jn_z1_prime);

Bn = (m2 .* m1 .* x .* Jn_z1 .* Jn_z2_prime - m1 .* m2 .* x .* Jn_z2 .* Jn_z1_prime) ...
    ./ (m1 .* Jn_z1_prime .* m2 .* x .* Yn_z2 - m2 .* Yn_z2_prime .* m1 .* x .* Jn_z1);

an_c = (y .* Jn_y .* (Jn_z3_prime + An .* Yn_z3_prime) ...
    - m2 .* Jn_y_prime .* (z3 .* Jn_z3 + An .* z3 .* Yn_z3)) ...
    ./ (y .* Hn_y .* (Jn_z3_prime + An .* Yn_z3_prime) ...
    - m2 .* Hn_y_prime .* (z3 .* Jn_z3 + An .* z3 .* Yn_z3));

bn_c = (m2 .* y .* Jn_y .* (Jn_z3_prime + Bn .* Yn_z3_prime) ...
    - Jn_y_prime .* (z3 .* Jn_z3 + Bn .* z3 .* Yn_z3)) ...
    ./ (m2 .* y .* Hn_y .* (Jn_z3_prime + Bn .* Yn_z3_prime) ...
    - Hn_y_prime .* (z3 .* Jn_z3 + Bn .* z3 .* Yn_z3));

% calculate an and bn for the core, with no coating:

an = (m1.^2 .* Jn_z1 .* Jn_x_prime - Jn_x .* Jn_z1_prime) ...
    ./ (m1.^2 .* Jn_z1 .* Hn_x_prime - Hn_x .* Jn_z1_prime);

bn = (Jn_z1 .* Jn_x_prime - Jn_x .* Jn_z1_prime) ...
    ./ (Jn_z1 .* Hn_x_prime - Hn_x .* Jn_z1_prime);

% % calculate cn and dn (don't really need them):
% 
% cn = (Jn_x .* Hn_x_prime - Hn_x .* Jn_x_prime) ...
%     ./ (Jn_z1 .* Hn_x_prime - Hn_x .* Jn_z1_prime);
% 
% dn = (m1 .* Jn_x .* Hn_x_prime - m1 .* Hn_x .* Jn_x_prime) ...
%     ./ (m1.^2 .* Jn_z1 .* Hn_x_prime - Hn_x .* Jn_z1_prime);



% bx = besselj(nu, x).*sqx;
% bz = besselj(nu, z).*sqz;
% yx = bessely(nu, x).*sqx;
% hx = bx+i*yx;
% b1x=[sin(x)/x, bx(1:nmax-1)];
% b1z=[sin(z)/z, bz(1:nmax-1)];
% y1x=[-cos(x)/x, yx(1:nmax-1)];
% h1x= b1x+i*y1x;
% ax = x.*b1x-n.*bx;
% az = z.*b1z-n.*bz;
% ahx= x.*h1x-n.*hx;
% an = (m2.*bz.*ax-bx.*az)./(m2.*bz.*ahx-hx.*az);
% bn = (bz.*ax-bx.*az)./(bz.*ahx-hx.*az);
% cn = (bx.*ahx-hx.*ax)./(bz.*ahx-hx.*az);
% dn = m.*(bx.*ahx-hx.*ax)./(m2.*bz.*ahx-hx.*az);
result=[an_c; bn_c; an; bn];